#!/usr/bin/env python3
import os
from pathlib import Path

required = [
    "project.godot",
    "export_presets.cfg",
    "README.md",
    "BUILD_INSTRUCTIONS.md",
    "scenes/menus/main_menu.tscn",
    "scenes/mission/mission_01.tscn",
    "scripts/autoload/game_state.gd",
    "scripts/player/player_controller.gd",
    ".github/workflows/build_android.yml",
    ".github/workflows/build_windows.yml",
]

root = Path(".")
missing = []
for r in required:
    if not (root / r).exists():
        missing.append(r)

if missing:
    print("MISSING FILES:")
    for m in missing:
        print("  -", m)
    exit(1)
else:
    print("All required files present.")
    gd_count = len(list(root.rglob("*.gd")))
    tscn_count = len(list(root.rglob("*.tscn")))
    print(f"Scripts: {gd_count}  Scenes: {tscn_count}")
    exit(0)
