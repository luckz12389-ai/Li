# TUTORIAL DE COMPILAÇÃO — Amazon Frontline

Você **não precisa** instalar Godot, Android Studio, nem nenhum programa de desenvolvimento.

Este tutorial é para quem está usando **celular Android** (ou qualquer dispositivo) e quer gerar o APK e a versão Windows só pelo site do GitHub.

---

## PARTE 1 — Criar o repositório no GitHub

1. Abra o navegador e entre em: **https://github.com**
2. Faça login (ou crie uma conta gratuita).
3. Toque no botão **+** (canto superior direito) → **New repository**.
4. Preencha:
   - **Repository name:** `amazon-frontline` (ou outro nome que quiser)
   - Deixe **Public** (ou Private, se preferir)
   - **NÃO** marque “Add a README file”
   - **NÃO** adicione .gitignore nem licença
5. Toque em **Create repository**.

Agora você tem um repositório vazio.

---

## PARTE 2 — Enviar os arquivos do jogo

### No celular (site do GitHub)

1. Abra o repositório que você acabou de criar.
2. Toque em **Add file** → **Upload files**.
3. Descompacte o arquivo `Amazon_Frontline_Complete.zip` no seu celular (use o gerenciador de arquivos).
4. Entre na pasta **Amazon_Frontline**.
5. Selecione **todos** os arquivos e pastas de dentro dela:
   - `project.godot`
   - `export_presets.cfg`
   - `README.md`
   - `BUILD_INSTRUCTIONS.md`
   - pastas `scenes`, `scripts`, `assets`, `.github`, etc.
6. Arraste ou selecione tudo e faça o upload.
7. Role até o final da página e toque em **Commit changes**.

**Dica:** Se o celular limitar o número de arquivos de uma vez, envie em partes (primeiro as pastas principais, depois o resto).

### Alternativa (se tiver um PC)

- Descompacte o ZIP.
- Use o GitHub Desktop ou o comando `git` para enviar a pasta `Amazon_Frontline`.

---

## PARTE 3 — Compilar o APK (Android)

1. No repositório, toque na aba **Actions** (no topo).
2. Na lista da esquerda você verá os fluxos:
   - **Build Android APK**
   - **Build Windows**
   - **Validate Project**
3. Toque em **Build Android APK**.
4. Toque no botão **Run workflow** (lado direito).
5. Confirme tocando novamente em **Run workflow**.
6. Aguarde. A primeira vez demora de **5 a 20 minutos** (o GitHub baixa o Godot e os templates).
7. Quando ficar com o símbolo verde de sucesso:
   - Abra a execução que acabou de terminar.
   - Role até a seção **Artifacts**.
   - Baixe o arquivo **AmazonFrontline-Android**.
8. Descompacte o artefato baixado. Dentro deve haver o APK (ou um arquivo de notas se a exportação precisar de ajuste extra).

---

## PARTE 4 — Instalar o APK no Android

1. Abra as **Configurações** do celular.
2. Procure por **Instalar apps desconhecidos** / **Fontes desconhecidas** / **Instalar aplicativos desconhecidos**.
3. Permita a instalação para o navegador ou o gerenciador de arquivos que você usa.
4. Abra o arquivo `.apk` e confirme a instalação.
5. Abra o jogo **Amazon Frontline**.

---

## PARTE 5 — Compilar a versão Windows (opcional)

1. Na aba **Actions**, escolha **Build Windows**.
2. Toque em **Run workflow** → confirme.
3. Quando terminar, baixe o artefato **AmazonFrontline-Windows**.
4. No PC, descompacte e execute `AmazonFrontline.exe`.

---

## Observações importantes

- O fluxo Android gera um **APK de debug** (não tem chave de assinatura de produção no repositório — isso é intencional e seguro).
- A primeira execução de cada fluxo é mais lenta porque baixa o Godot 4.3 e os templates de exportação.
- Se a exportação Android falhar no runner, o artefato ainda assim será gerado com um arquivo de notas explicando o que faltou. O projeto em si está configurado corretamente.
- **Nunca** coloque senhas, keystores reais ou segredos dentro do repositório.

---

## Problemas comuns e soluções

| Problema                              | O que fazer                                              |
|---------------------------------------|----------------------------------------------------------|
| Não aparece nenhum fluxo em Actions   | Confirme que a pasta `.github/workflows/` foi enviada    |
| “No artifacts” / sem artefatos        | Abra o log da execução com falha e veja o erro           |
| APK não instala                       | Ative “fontes desconhecidas” e tente outro gerenciador   |
| Fluxo fica vermelho na primeira vez   | Rode de novo; às vezes o download do Godot falha temporariamente |
| Versão do Godot diferente             | Os fluxos estão fixados no Godot **4.3-stable**          |

---

## Resumo visual do caminho

```
Baixar ZIP → Descompactar → Criar repositório no GitHub
     → Enviar todos os arquivos → Aba Actions
     → Run workflow (Build Android APK)
     → Baixar artefato → Instalar APK
```

Pronto. Depois que o APK estiver no celular, o jogo funciona **offline**, sem conta e sem internet.
