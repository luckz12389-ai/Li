# Histórico de mudanças

## [0.9.0-alpha] — 2025

### Adicionado
- Estrutura completa do projeto Godot 4.3
- Menu principal, briefing, seleção de esquadrão, configurações
- Missão jogável com 3 pontos de captura
- Controlador do jogador (andar / agachar / deitar / inclinar)
- Gerenciador de armas (5 armas, recuo, recarga, acertos por raycast)
- Sistema de saúde com regiões do corpo + itens médicos
- Sistema de ansiedade / estresse de combate (modular)
- Limite de deserção
- IA de esquadrão com comportamentos comandáveis
- IA inimiga defensores
- Controles touch Android + mapa de entrada Windows
- Sistema de salvamento local
- GitHub Actions: APK Android, Windows, Validação
- Documentação completa para fluxo pelo celular

### Observações
- Assets 3D são placeholders procedurais (cápsulas, caixas)
- Falas de voz são placeholders em log (prontas para substituição por .ogg)
- Ragdoll é um placeholder simples (desativa na morte)
- Navegação usa NavigationAgent3D do Godot (em builds mais completos precisa de navmesh)
