# AMAZON FRONTLINE — Operação Escudo Verde

**Versão 0.9.0-alpha**

Jogo de ação tática militar 3D para um jogador, ambientado em um conflito fictício na Amazônia.  
Feito com **Godot 4.3**. Projetado para ser compilado inteiramente pelo GitHub Actions — **não precisa instalar o Godot** no seu celular ou PC.

## Começo rápido (celular Android ou qualquer dispositivo)

1. Baixe ou clone este repositório.
2. No GitHub: crie um repositório novo → envie todos os arquivos.
3. Abra a aba **Actions**.
4. Execute o fluxo **Build Android APK** (ou **Build Windows**).
5. Baixe o artefato quando o fluxo terminar.

Passo a passo detalhado em **BUILD_INSTRUCTIONS.md**.

## O que o jogo tem (v0.9.0-alpha)

- Uma missão completa jogável com **3 pontos de captura**
- Sistema de comandos de esquadrão (Avançar, Reagrupar, Seguir, Manter posição, Supressão, Recuar, Médico…)
- Sistema de armas com 5 armas fictícias + recuo
- Controles touch para Android + teclado/mouse para Windows
- Saúde / ferimentos por região do corpo / itens médicos (torniquete, bandagem, kit médico, seringa)
- Sistema básico de sangramento e estresse de combate (ansiedade)
- Limite de deserção
- Salvamento local offline
- Presets gráficos e opções de acessibilidade
- Interface em português brasileiro e placeholders de voz aliada
- Placeholders de voz inimiga em espanhol colombiano

## Status honesto

Este é um **protótipo funcional** gerado para ser compilável de imediato:

| Sistema                         | Status                              |
|---------------------------------|-------------------------------------|
| Missão + 3 objetivos            | Funcionando                         |
| Movimento / câmera do jogador   | Funcionando                         |
| Armas + recuo + acertos         | Funcionando (raycast)               |
| Comandos de IA do esquadrão     | Funcionando (navegação básica)      |
| IA inimiga                      | Funcionando (guarda/combate simples)|
| Pontos de captura               | Funcionando                         |
| Menus / HUD / configurações     | Funcionando                         |
| Exportação Android + Windows    | Configurada (GitHub Actions)        |
| Arte 3D completa da floresta    | Geometria placeholder               |
| Dublagem real                   | Placeholder (documentado)           |
| Ragdoll avançado                | Placeholder (morte desativa)        |
| Conjunto completo de animações  | Não incluído (proxies de cápsula)   |

Todos os loops principais de jogabilidade estão implementados e modulares. Arte e áudio podem ser trocados depois sem reescrever os sistemas.

## Controles

### Windows
- **WASD** – Mover  
- **Mouse** – Olhar  
- **Botão esquerdo** – Atirar  
- **Botão direito** – Mirar  
- **R** – Recarregar  
- **C** – Agachar  
- **Z** – Deitar  
- **Q / E** – Inclinar  
- **Tab** – Comandos do esquadrão  
- **M** – Mapa tático (placeholder)  
- **Esc** – Pausar  

### Android
- Joystick virtual esquerdo – Mover  
- Toque e arraste (lado direito) – Olhar (básico)  
- Botões: Atirar / Mirar / Recarregar / Agachar / Comandos  

## Licença

Veja LICENSE.md. Código original e ambientação fictícia.  
Nomes de armas são padronizações fictícias, não marcas reais.

## Créditos

Estrutura e sistemas gerados para uso educacional / hobby.
