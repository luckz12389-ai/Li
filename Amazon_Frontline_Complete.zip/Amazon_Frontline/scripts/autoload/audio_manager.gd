extends Node
## Simple audio manager – uses procedural / placeholder tones
## Real voice lines would be added as .ogg files under assets/audio/

var sfx_player: AudioStreamPlayer
var music_player: AudioStreamPlayer
var voice_player: AudioStreamPlayer

# Placeholder tone generators (no external assets required)
func _ready() -> void:
    sfx_player = AudioStreamPlayer.new()
    music_player = AudioStreamPlayer.new()
    voice_player = AudioStreamPlayer.new()
    add_child(sfx_player)
    add_child(music_player)
    add_child(voice_player)
    sfx_player.bus = "Master"
    music_player.bus = "Master"
    voice_player.bus = "Master"

func play_sfx(name: String) -> void:
    # In a full build these would load real AudioStream resources.
    # For the generated project we log and play a short beep.
    print("[Audio] SFX: ", name)
    # Could generate a short AudioStreamGenerator here if needed.

func play_voice(line_id: String, language: String = "pt_BR") -> void:
    print("[Audio] Voice (", language, "): ", line_id)
    # Fallback: no real voice files yet – documented in README.

func play_music(track: String) -> void:
    print("[Audio] Music: ", track)

func set_master_volume(v: float) -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(clamp(v, 0.0, 1.0)))
