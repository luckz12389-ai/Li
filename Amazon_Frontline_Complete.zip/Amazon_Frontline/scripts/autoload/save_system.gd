extends Node
## Local offline save system

const SAVE_PATH := "user://amazon_frontline_save.json"

func save_game() -> void:
    var data := {
        "version": "0.9.0",
        "completed_missions": [],
        "settings": {
            "master_volume": GameState.master_volume,
            "sfx_volume": GameState.sfx_volume,
            "music_volume": GameState.music_volume,
            "mouse_sensitivity": GameState.mouse_sensitivity,
            "graphics_preset": GameState.graphics_preset,
            "blood_effects": GameState.blood_effects_enabled,
            "camera_shake": GameState.camera_shake,
            "anxiety_visuals": GameState.anxiety_visuals,
        }
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data, "\t"))
        file.close()
        print("[Save] Game saved")

func load_game() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not file:
        return {}
    var json := JSON.new()
    var err := json.parse(file.get_as_text())
    file.close()
    if err != OK:
        return {}
    var data: Dictionary = json.data
    if data.has("settings"):
        var s: Dictionary = data["settings"]
        GameState.master_volume = s.get("master_volume", 1.0)
        GameState.sfx_volume = s.get("sfx_volume", 1.0)
        GameState.music_volume = s.get("music_volume", 0.7)
        GameState.mouse_sensitivity = s.get("mouse_sensitivity", 0.3)
        GameState.graphics_preset = s.get("graphics_preset", 1)
        GameState.blood_effects_enabled = s.get("blood_effects", true)
        GameState.camera_shake = s.get("camera_shake", true)
        GameState.anxiety_visuals = s.get("anxiety_visuals", true)
    print("[Save] Game loaded")
    return data
