extends Node
## Global game state for Amazon Frontline

signal mission_started
signal mission_completed(success: bool)
signal objective_captured(id: String)
signal squad_command_issued(cmd: String)
signal player_died
signal anxiety_changed(level: int)

enum GraphicsPreset { LOW, MEDIUM, HIGH }
enum AnxietyLevel { CALM, ALERT, ANXIOUS, HIGHLY_STRESSED, RECOVERING }

var current_mission: String = ""
var objectives_captured: Array[String] = []
var mission_active: bool = false
var is_paused: bool = false

# Squad limits
const MAX_SNIPER := 1
const MAX_ASSAULT := 4
const MAX_RECON := 2
const MAX_RIFLEMEN := 2

var selected_squad: Array[Dictionary] = []
var player_health: float = 100.0
var player_anxiety: AnxietyLevel = AnxietyLevel.CALM
var blood_effects_enabled: bool = true
var graphics_preset: GraphicsPreset = GraphicsPreset.MEDIUM

# Settings
var master_volume: float = 1.0
var sfx_volume: float = 1.0
var music_volume: float = 0.7
var mouse_sensitivity: float = 0.3
var camera_shake: bool = true
var anxiety_visuals: bool = true
var language: String = "pt_BR"  # Brazilian Portuguese default

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS

func start_mission(mission_id: String) -> void:
    current_mission = mission_id
    objectives_captured.clear()
    mission_active = true
    player_health = 100.0
    player_anxiety = AnxietyLevel.CALM
    mission_started.emit()

func capture_objective(obj_id: String) -> void:
    if obj_id not in objectives_captured:
        objectives_captured.append(obj_id)
        objective_captured.emit(obj_id)
        if objectives_captured.size() >= 3:
            complete_mission(true)

func complete_mission(success: bool) -> void:
    mission_active = false
    mission_completed.emit(success)

func set_anxiety(level: AnxietyLevel) -> void:
    player_anxiety = level
    anxiety_changed.emit(level)

func can_add_unit(unit_type: String) -> bool:
    var count := 0
    for u in selected_squad:
        if u.get("type", "") == unit_type:
            count += 1
    match unit_type:
        "sniper": return count < MAX_SNIPER
        "assault": return count < MAX_ASSAULT
        "recon": return count < MAX_RECON
        "rifleman": return count < MAX_RIFLEMEN
    return false

func add_unit(unit: Dictionary) -> bool:
    if can_add_unit(unit.get("type", "")):
        selected_squad.append(unit)
        return true
    return false

func clear_squad() -> void:
    selected_squad.clear()
