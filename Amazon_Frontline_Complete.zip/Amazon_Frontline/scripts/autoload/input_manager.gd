extends Node
## Handles both keyboard/mouse and touch controls

signal command_requested(cmd: String)

var is_mobile: bool = false
var touch_joystick_vector: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO

func _ready() -> void:
    is_mobile = OS.has_feature("mobile") or OS.has_feature("android")
    print("[Input] Mobile detected: ", is_mobile)

func get_move_vector() -> Vector2:
    if is_mobile:
        return touch_joystick_vector
    var v := Vector2.ZERO
    if Input.is_action_pressed("move_forward"):
        v.y -= 1
    if Input.is_action_pressed("move_back"):
        v.y += 1
    if Input.is_action_pressed("move_left"):
        v.x -= 1
    if Input.is_action_pressed("move_right"):
        v.x += 1
    return v.normalized()

func is_firing() -> bool:
    return Input.is_action_pressed("fire")

func is_aiming() -> bool:
    return Input.is_action_pressed("aim")

func just_reloaded() -> bool:
    return Input.is_action_just_pressed("reload")

func just_crouched() -> bool:
    return Input.is_action_just_pressed("crouch")

func just_prone() -> bool:
    return Input.is_action_just_pressed("prone")

func just_lean_left() -> bool:
    return Input.is_action_just_pressed("lean_left")

func just_lean_right() -> bool:
    return Input.is_action_just_pressed("lean_right")

func just_squad_menu() -> bool:
    return Input.is_action_just_pressed("squad_menu")

func just_map() -> bool:
    return Input.is_action_just_pressed("tactical_map")

func just_pause() -> bool:
    return Input.is_action_just_pressed("pause")
