extends CharacterBody3D
class_name EnemyAI
## Simple enemy defender for capture points

@export var max_health: float = 80.0
@export var damage: float = 18.0
@export var detection_range: float = 35.0
@export var attack_range: float = 25.0

var health: float = 80.0
var is_alive: bool = true
var target: Node3D = null
var home_position: Vector3
var state: String = "guard"  # guard, combat, search

func _ready() -> void:
    health = max_health
    home_position = global_position
    add_to_group("enemies")

func _physics_process(delta: float) -> void:
    if not is_alive:
        return
    _find_target()
    match state:
        "guard":
            # Idle / slight wander near home
            pass
        "combat":
            if target and is_instance_valid(target):
                var dist = global_position.distance_to(target.global_position)
                if dist < attack_range:
                    look_at(target.global_position)
                    # Simplified fire
                    if randf() < 0.02:
                        if target.has_method("take_damage"):
                            target.take_damage(damage, global_position, "torso")
                else:
                    # Move closer
                    var dir = (target.global_position - global_position).normalized()
                    velocity = dir * 3.5
                    move_and_slide()
        "search":
            pass

func _find_target() -> void:
    var player = get_tree().get_first_node_in_group("player")
    if player and global_position.distance_to(player.global_position) < detection_range:
        target = player
        state = "combat"
        return
    for s in get_tree().get_nodes_in_group("squad"):
        if s.is_alive and global_position.distance_to(s.global_position) < detection_range:
            target = s
            state = "combat"
            return
    if state == "combat" and (not target or not is_instance_valid(target)):
        state = "guard"
        target = null

func take_damage(amount: float, _hit_pos: Vector3, _region: String = "torso") -> void:
    if not is_alive:
        return
    health -= amount
    if health <= 0.0:
        is_alive = false
        $CollisionShape3D.disabled = true
        # Placeholder death
        queue_free()  # or ragdoll activation
