extends CharacterBody3D
class_name SquadMember
## AI teammate with commandable behaviour

enum Command { FOLLOW, HOLD, ADVANCE, REGROUP, SUPPRESS, ATTACK, DEFEND, RETREAT, MEDIC }

@export var unit_type: String = "assault"
@export var unit_name: String = "Soldado"
@export var max_health: float = 100.0

var health: float = 100.0
var current_command: Command = Command.FOLLOW
var target_position: Vector3 = Vector3.ZERO
var attack_target: Node3D = null
var is_alive: bool = true
var speed: float = 4.0

@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D

func _ready() -> void:
    health = max_health
    add_to_group("squad")

func _physics_process(delta: float) -> void:
    if not is_alive:
        return
    match current_command:
        Command.FOLLOW:
            _follow_player(delta)
        Command.HOLD:
            _hold(delta)
        Command.ADVANCE:
            _move_to(target_position, delta)
        Command.REGROUP:
            _move_to(target_position, delta)
        Command.SUPPRESS, Command.ATTACK:
            _engage(delta)
        Command.DEFEND:
            _defend(delta)
        Command.RETREAT:
            _move_to(target_position, delta)
        Command.MEDIC:
            _medic_behaviour(delta)

func issue_command(cmd: Command, pos: Vector3 = Vector3.ZERO, target: Node3D = null) -> void:
    current_command = cmd
    target_position = pos
    attack_target = target
    print("[Squad] ", unit_name, " received command: ", Command.keys()[cmd])

func take_damage(amount: float, _hit_pos: Vector3, _region: String = "torso") -> void:
    if not is_alive:
        return
    health -= amount
    if health <= 0.0:
        is_alive = false
        # Simple death – disable collision, play ragdoll placeholder
        $CollisionShape3D.disabled = true
        visible = false  # placeholder; real ragdoll would activate here
        print("[Squad] ", unit_name, " down")

func _follow_player(delta: float) -> void:
    var player = get_tree().get_first_node_in_group("player")
    if player:
        var dist = global_position.distance_to(player.global_position)
        if dist > 6.0:
            nav_agent.target_position = player.global_position
            _move_along_nav(delta)

func _hold(_delta: float) -> void:
    velocity = Vector3.ZERO

func _move_to(pos: Vector3, delta: float) -> void:
    nav_agent.target_position = pos
    _move_along_nav(delta)

func _engage(delta: float) -> void:
    if attack_target and is_instance_valid(attack_target):
        # Face and fire (simplified)
        look_at(attack_target.global_position)
        # Placeholder shooting
    else:
        _follow_player(delta)

func _defend(delta: float) -> void:
    # Stay near objective
    if target_position != Vector3.ZERO:
        if global_position.distance_to(target_position) > 8.0:
            _move_to(target_position, delta)

func _medic_behaviour(delta: float) -> void:
    # Move to nearest injured squadmate
    var injured = null
    var best_d := 999.0
    for s in get_tree().get_nodes_in_group("squad"):
        if s != self and s.is_alive and s.health < 60.0:
            var d = global_position.distance_to(s.global_position)
            if d < best_d:
                best_d = d
                injured = s
    if injured:
        _move_to(injured.global_position, delta)
        if best_d < 2.5:
            injured.health = min(injured.max_health, injured.health + 20.0 * delta)

func _move_along_nav(delta: float) -> void:
    if nav_agent.is_navigation_finished():
        velocity = Vector3.ZERO
        return
    var next = nav_agent.get_next_path_position()
    var dir = (next - global_position).normalized()
    velocity = dir * speed
    move_and_slide()
