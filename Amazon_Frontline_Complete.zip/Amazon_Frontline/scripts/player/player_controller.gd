extends CharacterBody3D
class_name PlayerController
## First-person player controller with stance, lean, recoil, injury effects

@export var walk_speed: float = 4.5
@export var sprint_speed: float = 7.0
@export var crouch_speed: float = 2.5
@export var prone_speed: float = 1.2
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.003

@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var weapon_manager: Node = $WeaponManager
@onready var health_system: Node = $HealthSystem
@onready var anxiety_system: Node = $AnxietySystem

enum Stance { STAND, CROUCH, PRONE }
var stance: Stance = Stance.STAND
var lean: float = 0.0  # -1 left, +1 right
var is_aiming: bool = false
var current_speed: float = 0.0

# Injury modifiers
var move_multiplier: float = 1.0
var aim_stability: float = 1.0

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    if health_system:
        health_system.injury_changed.connect(_on_injury_changed)

func _input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * mouse_sensitivity * GameState.mouse_sensitivity)
        camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity * GameState.mouse_sensitivity)
        camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, deg_to_rad(-80), deg_to_rad(80))

    if InputManager.just_crouched():
        toggle_crouch()
    if InputManager.just_prone():
        toggle_prone()
    if InputManager.just_lean_left():
        lean = -1.0 if lean >= 0 else 0.0
    if InputManager.just_lean_right():
        lean = 1.0 if lean <= 0 else 0.0

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta

    var input_dir := InputManager.get_move_vector()
    var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

    var target_speed := walk_speed
    match stance:
        Stance.CROUCH: target_speed = crouch_speed
        Stance.PRONE: target_speed = prone_speed
    if Input.is_action_pressed("sprint") and stance == Stance.STAND and move_multiplier > 0.6:
        target_speed = sprint_speed

    target_speed *= move_multiplier
    current_speed = target_speed

    if direction:
        velocity.x = direction.x * target_speed
        velocity.z = direction.z * target_speed
    else:
        velocity.x = move_toward(velocity.x, 0, target_speed)
        velocity.z = move_toward(velocity.z, 0, target_speed)

    # Lean visual
    camera_pivot.rotation.z = lerp(camera_pivot.rotation.z, -lean * 0.25, delta * 8.0)

    move_and_slide()

    # Desertion boundary check (simple radius for demo)
    if global_position.length() > 180.0:
        _check_desertion()

func toggle_crouch() -> void:
    if stance == Stance.CROUCH:
        stance = Stance.STAND
    else:
        stance = Stance.CROUCH
    _update_collision()

func toggle_prone() -> void:
    if stance == Stance.PRONE:
        stance = Stance.STAND
    else:
        stance = Stance.PRONE
    _update_collision()

func _update_collision() -> void:
    # Simple height change – real project would use different shapes
    match stance:
        Stance.STAND:
            $CollisionShape3D.shape.height = 1.8
            $CollisionShape3D.position.y = 0.9
        Stance.CROUCH:
            $CollisionShape3D.shape.height = 1.1
            $CollisionShape3D.position.y = 0.55
        Stance.PRONE:
            $CollisionShape3D.shape.height = 0.5
            $CollisionShape3D.position.y = 0.25

func _on_injury_changed(region: String, severity: float) -> void:
    if region in ["left_leg", "right_leg"]:
        move_multiplier = clamp(1.0 - severity * 0.6, 0.3, 1.0)
    if region in ["left_arm", "right_arm"]:
        aim_stability = clamp(1.0 - severity * 0.7, 0.2, 1.0)

func _check_desertion() -> void:
    # Warn then fail – see DesertionSystem
    print("[Player] Approaching desertion boundary")
    if global_position.length() > 200.0:
        GameState.complete_mission(false)
