extends Node
class_name HealthSystem
## Body-region damage, bleeding, medical items

signal injury_changed(region: String, severity: float)
signal health_changed(current: float, max_health: float)
signal died
signal bleeding_warning

const MAX_HEALTH := 100.0
var health: float = MAX_HEALTH
var regions := {
    "head": 0.0,
    "torso": 0.0,
    "left_arm": 0.0,
    "right_arm": 0.0,
    "left_leg": 0.0,
    "right_leg": 0.0
}
var bleeding_rate: float = 0.0
var is_alive: bool = true

# Inventory
var tourniquets: int = 2
var bandages: int = 4
var medkits: int = 1
var syringes: int = 1

func _process(delta: float) -> void:
    if not is_alive:
        return
    if bleeding_rate > 0.0:
        health -= bleeding_rate * delta
        if health <= 0.0:
            _die()
        health_changed.emit(health, MAX_HEALTH)

func take_damage(amount: float, hit_pos: Vector3, preferred_region: String = "torso") -> void:
    if not is_alive:
        return
    var region := preferred_region
    # Simple random region bias if not specified
    if preferred_region == "torso" and randf() < 0.3:
        var keys = regions.keys()
        region = keys[randi() % keys.size()]

    var mult := 1.0
    match region:
        "head": mult = 2.2
        "torso": mult = 1.0
        "left_arm", "right_arm": mult = 0.7
        "left_leg", "right_leg": mult = 0.75

    var final := amount * mult
    health = max(0.0, health - final)
    regions[region] = clamp(regions[region] + final / 50.0, 0.0, 1.0)
    injury_changed.emit(region, regions[region])

    # Bleeding chance
    if final > 15.0 and randf() < 0.4:
        bleeding_rate += 2.0 + final * 0.05
        bleeding_warning.emit()

    health_changed.emit(health, MAX_HEALTH)
    if health <= 0.0:
        _die()

func use_item(item: String) -> bool:
    match item:
        "tourniquet":
            if tourniquets <= 0:
                return false
            # Stabilize worst limb
            var worst := ""
            var sev := 0.0
            for r in ["left_arm", "right_arm", "left_leg", "right_leg"]:
                if regions[r] > sev:
                    sev = regions[r]
                    worst = r
            if worst != "" and sev > 0.3:
                regions[worst] = max(0.0, regions[worst] - 0.5)
                bleeding_rate = max(0.0, bleeding_rate - 3.0)
                tourniquets -= 1
                injury_changed.emit(worst, regions[worst])
                return true
        "bandage":
            if bandages <= 0:
                return false
            bandages -= 1
            bleeding_rate = max(0.0, bleeding_rate - 1.5)
            health = min(MAX_HEALTH, health + 8.0)
            health_changed.emit(health, MAX_HEALTH)
            return true
        "medkit":
            if medkits <= 0:
                return false
            medkits -= 1
            for r in regions:
                regions[r] = max(0.0, regions[r] - 0.4)
            bleeding_rate = 0.0
            health = min(MAX_HEALTH, health + 35.0)
            health_changed.emit(health, MAX_HEALTH)
            return true
        "syringe":
            if syringes <= 0:
                return false
            syringes -= 1
            # Temporary pain reduction – reduces aim penalty briefly
            return true
    return false

func _die() -> void:
    is_alive = false
    died.emit()
    GameState.player_died.emit()
