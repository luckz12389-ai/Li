extends Node
class_name WeaponManager
## Handles weapon switching, firing, recoil, reload

signal weapon_changed(weapon_name: String)
signal ammo_changed(current: int, reserve: int)

var weapons: Array[Dictionary] = [
    {
        "id": "ak_pattern",
        "name": "AK-Pattern Rifle",
        "damage": 32.0,
        "fire_rate": 0.12,
        "magazine": 30,
        "reserve": 90,
        "reload_time": 2.4,
        "recoil_v": 1.8,
        "recoil_h": 0.6,
        "spread": 1.2,
        "automatic": true
    },
    {
        "id": "akm_pattern",
        "name": "AKM-Pattern Rifle",
        "damage": 35.0,
        "fire_rate": 0.14,
        "magazine": 30,
        "reserve": 90,
        "reload_time": 2.6,
        "recoil_v": 2.1,
        "recoil_h": 0.8,
        "spread": 1.4,
        "automatic": true
    },
    {
        "id": "hk_pattern",
        "name": "HK-Pattern Rifle",
        "damage": 28.0,
        "fire_rate": 0.09,
        "magazine": 30,
        "reserve": 120,
        "reload_time": 2.2,
        "recoil_v": 1.4,
        "recoil_h": 0.4,
        "spread": 0.9,
        "automatic": true
    },
    {
        "id": "glock_pattern",
        "name": "Glock-Pattern Pistol",
        "damage": 22.0,
        "fire_rate": 0.18,
        "magazine": 17,
        "reserve": 51,
        "reload_time": 1.6,
        "recoil_v": 1.2,
        "recoil_h": 0.5,
        "spread": 1.8,
        "automatic": false
    },
    {
        "id": "deagle_pattern",
        "name": "Desert Eagle-Pattern",
        "damage": 55.0,
        "fire_rate": 0.35,
        "magazine": 7,
        "reserve": 28,
        "reload_time": 2.0,
        "recoil_v": 4.5,
        "recoil_h": 1.5,
        "spread": 2.5,
        "automatic": false
    }
]

var current_index: int = 0
var current_ammo: int = 30
var is_reloading: bool = false
var fire_cooldown: float = 0.0
var recoil_offset: Vector2 = Vector2.ZERO

@onready var player: CharacterBody3D = get_parent()
@onready var camera: Camera3D = get_node("../CameraPivot/Camera3D")

func _ready() -> void:
    current_ammo = weapons[0]["magazine"]
    ammo_changed.emit(current_ammo, weapons[0]["reserve"])

func _process(delta: float) -> void:
    fire_cooldown = max(0.0, fire_cooldown - delta)
    # Recover recoil
    recoil_offset = recoil_offset.lerp(Vector2.ZERO, delta * 6.0)
    if camera:
        camera.rotation.x += recoil_offset.y * 0.01
        camera.rotation.y += recoil_offset.x * 0.01

    if InputManager.is_firing() and not is_reloading:
        try_fire()
    if InputManager.just_reloaded():
        start_reload()

    # Weapon switch 1-5
    for i in range(5):
        if Input.is_key_pressed(KEY_1 + i):
            switch_weapon(i)

func try_fire() -> void:
    var w: Dictionary = weapons[current_index]
    if fire_cooldown > 0.0 or current_ammo <= 0:
        if current_ammo <= 0:
            start_reload()
        return
    current_ammo -= 1
    fire_cooldown = w["fire_rate"]
    ammo_changed.emit(current_ammo, w["reserve"])

    # Recoil
    var stability: float = 1.0
    if player.has_method("get") and "aim_stability" in player:
        stability = player.aim_stability
    var rv: float = w["recoil_v"] * (1.5 if not InputManager.is_aiming() else 0.7) / stability
    var rh: float = w["recoil_h"] * randf_range(-1.0, 1.0) / stability
    recoil_offset += Vector2(rh, -rv)

    # Raycast hit detection
    var space := player.get_world_3d().direct_space_state
    var from := camera.global_position
    var to := from + (-camera.global_transform.basis.z) * 200.0
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.collision_mask = 4 | 8  # enemies + squad (avoid self)
    var result := space.intersect_ray(query)
    if result:
        var collider = result.collider
        if collider.has_method("take_damage"):
            collider.take_damage(w["damage"], result.position, "torso")
        # Impact feedback
        AudioManager.play_sfx("impact")
    AudioManager.play_sfx("gunshot_" + w["id"])

func start_reload() -> void:
    if is_reloading:
        return
    var w: Dictionary = weapons[current_index]
    if current_ammo >= w["magazine"] or w["reserve"] <= 0:
        return
    is_reloading = true
    AudioManager.play_sfx("reload")
    await get_tree().create_timer(w["reload_time"]).timeout
    var needed: int = w["magazine"] - current_ammo
    var take: int = mini(needed, w["reserve"])
    current_ammo += take
    w["reserve"] -= take
    is_reloading = false
    ammo_changed.emit(current_ammo, w["reserve"])

func switch_weapon(index: int) -> void:
    if index < 0 or index >= weapons.size() or index == current_index:
        return
    current_index = index
    current_ammo = weapons[index]["magazine"]  # simplified
    weapon_changed.emit(weapons[index]["name"])
    ammo_changed.emit(current_ammo, weapons[index]["reserve"])
    AudioManager.play_sfx("weapon_switch")
