extends Node
class_name AnxietySystem
## Optional combat-stress system (respectful, non-graphic)

signal anxiety_updated(level: int)

var level: int = GameState.AnxietyLevel.CALM
var stress_points: float = 0.0
var recovery_timer: float = 0.0

func _process(delta: float) -> void:
    # Natural recovery when not under fire
    if stress_points > 0.0:
        stress_points = max(0.0, stress_points - delta * 1.5)
    _update_level()

func add_stress(amount: float, reason: String = "") -> void:
    stress_points = clamp(stress_points + amount, 0.0, 100.0)
    if reason != "":
        print("[Anxiety] +", amount, " (", reason, ")")
    _update_level()

func start_recovery() -> void:
    recovery_timer = 8.0
    level = GameState.AnxietyLevel.RECOVERING
    anxiety_updated.emit(level)
    GameState.set_anxiety(level)

func _update_level() -> void:
    var new_level: int
    if recovery_timer > 0.0:
        recovery_timer -= get_process_delta_time()
        new_level = GameState.AnxietyLevel.RECOVERING
    elif stress_points < 15.0:
        new_level = GameState.AnxietyLevel.CALM
    elif stress_points < 35.0:
        new_level = GameState.AnxietyLevel.ALERT
    elif stress_points < 60.0:
        new_level = GameState.AnxietyLevel.ANXIOUS
    else:
        new_level = GameState.AnxietyLevel.HIGHLY_STRESSED

    if new_level != level:
        level = new_level
        anxiety_updated.emit(level)
        GameState.set_anxiety(level)
        # Subtle effects only
        if level >= GameState.AnxietyLevel.ANXIOUS:
            AudioManager.play_sfx("heartbeat_soft")
