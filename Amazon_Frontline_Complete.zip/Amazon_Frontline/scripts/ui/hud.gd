extends CanvasLayer
class_name GameHUD
## Tactical HUD – health, ammo, objectives, squad status, commands

@onready var health_bar: ProgressBar = $Control/HealthBar
@onready var ammo_label: Label = $Control/AmmoLabel
@onready var objective_list: VBoxContainer = $Control/ObjectiveList
@onready var squad_panel: VBoxContainer = $Control/SquadPanel
@onready var command_menu: PanelContainer = $Control/CommandMenu
@onready var crosshair: Control = $Control/Crosshair
@onready var message_label: Label = $Control/MessageLabel

var command_open: bool = false

func _ready() -> void:
    command_menu.visible = false
    message_label.text = ""
    GameState.objective_captured.connect(_on_obj_captured)

func _process(_delta: float) -> void:
    if InputManager.just_squad_menu():
        toggle_command_menu()
    if InputManager.just_pause():
        get_tree().paused = not get_tree().paused

func update_health(current: float, max_h: float) -> void:
    health_bar.value = (current / max_h) * 100.0

func update_ammo(cur: int, reserve: int) -> void:
    ammo_label.text = str(cur) + " / " + str(reserve)

func _on_obj_captured(id: String) -> void:
    show_message("OBJETIVO CAPTURADO: " + id.to_upper())

func show_message(text: String, duration: float = 3.0) -> void:
    message_label.text = text
    await get_tree().create_timer(duration).timeout
    message_label.text = ""

func toggle_command_menu() -> void:
    command_open = not command_open
    command_menu.visible = command_open
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if command_open else Input.MOUSE_MODE_CAPTURED

func _on_command_pressed(cmd: String) -> void:
    GameState.squad_command_issued.emit(cmd)
    # Broadcast to all squad members
    for s in get_tree().get_nodes_in_group("squad"):
        if s.has_method("issue_command"):
            match cmd:
                "advance":
                    s.issue_command(s.Command.ADVANCE, s.global_position + (-s.global_transform.basis.z * 20.0))
                "regroup":
                    var player = get_tree().get_first_node_in_group("player")
                    if player:
                        s.issue_command(s.Command.REGROUP, player.global_position)
                "follow":
                    s.issue_command(s.Command.FOLLOW)
                "hold":
                    s.issue_command(s.Command.HOLD)
                "suppress":
                    s.issue_command(s.Command.SUPPRESS)
                "retreat":
                    var player = get_tree().get_first_node_in_group("player")
                    if player:
                        s.issue_command(s.Command.RETREAT, player.global_position - Vector3(0,0,15))
                "medic":
                    s.issue_command(s.Command.MEDIC)
    toggle_command_menu()
    show_message("Ordem: " + cmd.to_upper())
