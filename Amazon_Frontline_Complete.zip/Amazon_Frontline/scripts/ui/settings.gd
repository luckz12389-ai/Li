extends Control

func _ready() -> void:
    $VBox/GraphicsOption.add_item("Baixo", 0)
    $VBox/GraphicsOption.add_item("Médio", 1)
    $VBox/GraphicsOption.add_item("Alto", 2)
    $VBox/GraphicsOption.selected = GameState.graphics_preset
    $VBox/SensitivitySlider.value = GameState.mouse_sensitivity
    $VBox/BloodCheck.button_pressed = GameState.blood_effects_enabled
    $VBox/ShakeCheck.button_pressed = GameState.camera_shake
    $VBox/AnxietyCheck.button_pressed = GameState.anxiety_visuals
    $BackBtn.pressed.connect(_on_back)
    $VBox/GraphicsOption.item_selected.connect(_on_graphics)
    $VBox/SensitivitySlider.value_changed.connect(_on_sens)
    $VBox/BloodCheck.toggled.connect(func(v): GameState.blood_effects_enabled = v)
    $VBox/ShakeCheck.toggled.connect(func(v): GameState.camera_shake = v)
    $VBox/AnxietyCheck.toggled.connect(func(v): GameState.anxiety_visuals = v)

func _on_graphics(idx: int) -> void:
    GameState.graphics_preset = idx

func _on_sens(v: float) -> void:
    GameState.mouse_sensitivity = v

func _on_back() -> void:
    SaveSystem.save_game()
    get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn")
