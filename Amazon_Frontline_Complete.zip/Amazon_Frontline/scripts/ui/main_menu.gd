extends Control

func _ready() -> void:
    $VBox/NewMissionBtn.pressed.connect(_on_new_mission)
    $VBox/SquadBtn.pressed.connect(_on_squad)
    $VBox/SettingsBtn.pressed.connect(_on_settings)
    $VBox/QuitBtn.pressed.connect(_on_quit)
    SaveSystem.load_game()
    AudioManager.play_music("menu_theme")

func _on_new_mission() -> void:
    # Go to briefing then mission
    get_tree().change_scene_to_file("res://scenes/menus/briefing.tscn")

func _on_squad() -> void:
    get_tree().change_scene_to_file("res://scenes/menus/squad_select.tscn")

func _on_settings() -> void:
    get_tree().change_scene_to_file("res://scenes/menus/settings.tscn")

func _on_quit() -> void:
    get_tree().quit()
