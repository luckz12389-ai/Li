extends Control

var available_units := [
    {"type": "assault", "name": "Soldado Almeida"},
    {"type": "assault", "name": "Soldado Ribeiro"},
    {"type": "assault", "name": "Cabo Santos"},
    {"type": "assault", "name": "Soldado Lima"},
    {"type": "sniper", "name": "Atirador Costa"},
    {"type": "recon", "name": "Operador Drone Silva"},
    {"type": "recon", "name": "Batedor Oliveira"},
    {"type": "rifleman", "name": "Soldado Ferreira"},
    {"type": "rifleman", "name": "Soldado Rocha"},
]

func _ready() -> void:
    $BackBtn.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn"))
    $ConfirmBtn.pressed.connect(_on_confirm)
    _rebuild_list()

func _rebuild_list() -> void:
    for c in $UnitList.get_children():
        c.queue_free()
    for u in available_units:
        var btn := Button.new()
        var selected = false
        for s in GameState.selected_squad:
            if s["name"] == u["name"]:
                selected = true
                break
        btn.text = ("[X] " if selected else "[ ] ") + u["name"] + " (" + u["type"] + ")"
        btn.pressed.connect(_on_unit_toggle.bind(u))
        $UnitList.add_child(btn)

func _on_unit_toggle(unit: Dictionary) -> void:
    for i in range(GameState.selected_squad.size()):
        if GameState.selected_squad[i]["name"] == unit["name"]:
            GameState.selected_squad.remove_at(i)
            _rebuild_list()
            return
    if GameState.add_unit(unit):
        _rebuild_list()
    else:
        print("Limite de tipo atingido")

func _on_confirm() -> void:
    if GameState.selected_squad.is_empty():
        # Default squad
        GameState.add_unit(available_units[0])
        GameState.add_unit(available_units[1])
        GameState.add_unit(available_units[4])
    get_tree().change_scene_to_file("res://scenes/menus/main_menu.tscn")
