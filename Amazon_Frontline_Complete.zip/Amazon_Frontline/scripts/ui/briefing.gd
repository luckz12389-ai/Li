extends Control

func _ready() -> void:
    $StartBtn.pressed.connect(_on_start)

func _on_start() -> void:
    get_tree().change_scene_to_file("res://scenes/mission/mission_01.tscn")
