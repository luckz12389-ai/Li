extends CanvasLayer
class_name MobileControls
## Touch controls for Android

@onready var joystick_base: Control = $JoystickBase
@onready var joystick_knob: Control = $JoystickBase/Knob
@onready var fire_btn: TouchScreenButton = $FireButton
@onready var aim_btn: TouchScreenButton = $AimButton
@onready var reload_btn: TouchScreenButton = $ReloadButton
@onready var crouch_btn: TouchScreenButton = $CrouchButton
@onready var command_btn: TouchScreenButton = $CommandButton

var joystick_active: bool = false
var joystick_origin: Vector2 = Vector2.ZERO
var max_radius: float = 80.0

func _ready() -> void:
    visible = InputManager.is_mobile
    if not visible:
        return
    # Connect buttons
    fire_btn.pressed.connect(func(): Input.action_press("fire"))
    fire_btn.released.connect(func(): Input.action_release("fire"))
    aim_btn.pressed.connect(func(): Input.action_press("aim"))
    aim_btn.released.connect(func(): Input.action_release("aim"))
    reload_btn.pressed.connect(func(): Input.action_press("reload"))
    reload_btn.released.connect(func(): Input.action_release("reload"))
    crouch_btn.pressed.connect(func(): Input.action_press("crouch"))
    command_btn.pressed.connect(func(): Input.action_press("squad_menu"))

func _input(event: InputEvent) -> void:
    if not visible:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            var local = joystick_base.get_local_mouse_position() if false else event.position
            # Simplified – real implementation tracks touch index
            if _is_in_joystick_area(event.position):
                joystick_active = true
                joystick_origin = event.position
        else:
            joystick_active = false
            InputManager.touch_joystick_vector = Vector2.ZERO
            joystick_knob.position = Vector2(60, 60)
    elif event is InputEventScreenDrag and joystick_active:
        var delta = event.position - joystick_origin
        if delta.length() > max_radius:
            delta = delta.normalized() * max_radius
        joystick_knob.position = Vector2(60, 60) + delta
        InputManager.touch_joystick_vector = delta / max_radius

func _is_in_joystick_area(pos: Vector2) -> bool:
    return pos.x < 300 and pos.y > 400  # bottom-left zone
