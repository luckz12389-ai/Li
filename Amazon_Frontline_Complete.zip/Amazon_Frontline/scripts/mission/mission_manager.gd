extends Node
class_name MissionManager
## Controls the single playable mission

signal briefing_finished
signal victory
signal defeat

var objectives := ["forward_op", "river_crossing", "comms_outpost"]
var captured_count: int = 0

func _ready() -> void:
    GameState.objective_captured.connect(_on_objective_captured)
    GameState.mission_completed.connect(_on_mission_completed)
    GameState.player_died.connect(_on_player_died)

func start() -> void:
    GameState.start_mission("green_shield_01")
    AudioManager.play_voice("mission_start", "pt_BR")
    print("[Mission] Operation Green Shield – Begin")

func _on_objective_captured(id: String) -> void:
    captured_count += 1
    print("[Mission] Objective secured: ", id, " (", captured_count, "/3)")
    if captured_count >= 3:
        GameState.complete_mission(true)

func _on_mission_completed(success: bool) -> void:
    if success:
        victory.emit()
        AudioManager.play_voice("mission_complete", "pt_BR")
    else:
        defeat.emit()
        AudioManager.play_voice("mission_failed", "pt_BR")

func _on_player_died() -> void:
    GameState.complete_mission(false)
