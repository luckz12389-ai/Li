extends Area3D
class_name CapturePoint
## Capture zone with progress, states, defenders

signal captured(id: String)
signal state_changed(new_state: String)

@export var point_id: String = "obj_1"
@export var display_name: String = "Forward Observation Post"
@export var capture_time: float = 12.0
@export var capture_radius: float = 8.0

enum State { NEUTRAL, CONTESTED, CAPTURED }
var state: State = State.NEUTRAL
var progress: float = 0.0
var players_inside: int = 0
var enemies_inside: int = 0

@onready var mesh: MeshInstance3D = $MarkerMesh
@onready var label: Label3D = $Label3D

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    body_exited.connect(_on_body_exited)
    _update_visual()

func _process(delta: float) -> void:
    if state == State.CAPTURED:
        return
    if players_inside > 0 and enemies_inside == 0:
        progress += delta / capture_time
        if progress >= 1.0:
            progress = 1.0
            state = State.CAPTURED
            state_changed.emit("CAPTURED")
            captured.emit(point_id)
            GameState.capture_objective(point_id)
            AudioManager.play_voice("objective_secured", "pt_BR")
            _update_visual()
    elif players_inside > 0 and enemies_inside > 0:
        state = State.CONTESTED
        state_changed.emit("CONTESTED")
    elif players_inside == 0 and progress > 0.0:
        progress = max(0.0, progress - delta * 0.15)
        if progress <= 0.0:
            state = State.NEUTRAL
            state_changed.emit("NEUTRAL")
    _update_visual()

func _on_body_entered(body: Node3D) -> void:
    if body.is_in_group("player") or body.is_in_group("squad"):
        players_inside += 1
    elif body.is_in_group("enemies"):
        enemies_inside += 1

func _on_body_exited(body: Node3D) -> void:
    if body.is_in_group("player") or body.is_in_group("squad"):
        players_inside = max(0, players_inside - 1)
    elif body.is_in_group("enemies"):
        enemies_inside = max(0, enemies_inside - 1)

func _update_visual() -> void:
    if label:
        var pct := int(progress * 100)
        match state:
            State.NEUTRAL:
                label.text = display_name + "\n[NEUTRAL]"
                if mesh:
                    mesh.material_override = _make_mat(Color(0.7, 0.7, 0.2))
            State.CONTESTED:
                label.text = display_name + "\n[CONTESTED] " + str(pct) + "%"
                if mesh:
                    mesh.material_override = _make_mat(Color(0.9, 0.4, 0.1))
            State.CAPTURED:
                label.text = display_name + "\n[SECURED]"
                if mesh:
                    mesh.material_override = _make_mat(Color(0.2, 0.8, 0.3))

func _make_mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.emission_enabled = true
    m.emission = c
    m.emission_energy_multiplier = 0.6
    return m
